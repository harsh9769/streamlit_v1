"""AI Reasoning Chat - Gemini 2.0 Flash (official SDK)"""

import streamlit as st
import google.generativeai as genai

# ---------------- Page Config ----------------
st.set_page_config(
    page_title="AI Reasoning Chat",
    page_icon="🧠",
    layout="centered",
    initial_sidebar_state="collapsed",
)

# ---------------- Styles ----------------
st.markdown(
    """
    <style>
        #MainMenu {visibility: hidden;}
        footer {visibility: hidden;}
        .stChatMessage {padding: 1rem;}
        .stStatus {
            background-color: rgba(0, 0, 0, 0.05);
            border-radius: 0.5rem;
        }
        .block-container {
            padding-top: 2rem;
            padding-bottom: 6rem;
        }
    </style>
    """,
    unsafe_allow_html=True,
)

# ---------------- Gemini Setup ----------------
@st.cache_resource
def get_model():
    genai.configure(api_key=st.secrets["GOOGLE_API_KEY"])
    return genai.GenerativeModel(
        model_name="gemini-2.0-flash",
        generation_config={
            "temperature": 0.7,
            "max_output_tokens": 8192,
        },
    )

model = get_model()

# ---------------- Session State ----------------
if "messages" not in st.session_state:
    st.session_state.messages = []

# ---------------- UI ----------------
st.title("🧠 AI Reasoning Chat")
st.caption("Reasoning summary + streamed response")

with st.sidebar:
    st.header("⚙️ Settings")

    reasoning_depth = st.slider(
        "Reasoning Depth",
        min_value=1,
        max_value=5,
        value=3,
    )

    st.divider()

    if st.button("🗑️ Clear Chat", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

# ---------------- Render History ----------------
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        if msg["role"] == "assistant" and msg.get("thinking"):
            with st.status("Reasoning", state="complete"):
                st.markdown(f"```\n{msg['thinking']}\n```")
        st.markdown(msg["content"])

# ---------------- Chat Input ----------------
if prompt := st.chat_input("Ask me anything..."):
    st.session_state.messages.append({"role": "user", "content": prompt})

    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        thinking_placeholder = st.empty()
        response_placeholder = st.empty()

        # -------- SAFE Reasoning Summary --------
        reasoning_prompt = f"""
        Provide a concise reasoning summary.
        Do NOT reveal chain-of-thought.
        Depth level: {reasoning_depth}.
        Use bullet points.
        """

        reasoning_response = model.generate_content(
            reasoning_prompt + "\n\nUser question:\n" + prompt
        )

        thinking_text = reasoning_response.text.strip()
        thinking_placeholder.markdown(f"```\n{thinking_text}\n```")

        # -------- Final Answer (Streaming) --------
        response_text = ""
        stream = model.generate_content(prompt, stream=True)

        for chunk in stream:
            if chunk.text:
                response_text += chunk.text
                response_placeholder.markdown(response_text + "▌")

        response_placeholder.markdown(response_text)

        st.session_state.messages.append(
            {
                "role": "assistant",
                "content": response_text,
                "thinking": thinking_text,
            }
        )
