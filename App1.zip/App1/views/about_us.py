import streamlit as st

st.set_page_config(page_title="About Us", layout="wide")

# --- HEADER ---
st.image(
    "assets/icici_logo.png",
    width=220
)

st.title("About ICICI Prudential Asset Management Company")

st.markdown(
    """
ICICI Prudential Asset Management Company is one of India’s leading asset
management firms, committed to helping investors achieve long-term financial
goals through disciplined investment strategies and strong governance.

Our approach combines **deep market research**, **risk-aware portfolio
construction**, and **investor-centric solutions** across asset classes.
"""
)

st.divider()

# --- WHAT WE DO ---
st.header("What We Do")

st.markdown(
    """
### 🏦 Asset Management
We manage a wide range of mutual fund schemes across equity, debt, hybrid,
and alternative investment strategies—designed to suit different investor
risk profiles and horizons.

### 📊 Research-Driven Investing
Our investment decisions are backed by rigorous fundamental research,
macroeconomic analysis, and quantitative insights.

### 🌍 Global & Domestic Insights
We continuously monitor global and domestic economic developments,
policy trends, and market risks to ensure informed decision-making.

### 🤝 Investor-First Philosophy
Transparency, compliance, and long-term value creation remain at the core
of everything we do.
"""
)

st.divider()

# --- DISCLAIMER ---
st.caption(
    "This internal application is for informational purposes only and does not "
    "constitute investment advice or a solicitation to invest."
)
