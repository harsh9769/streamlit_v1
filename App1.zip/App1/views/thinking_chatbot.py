import os
import time
import streamlit as st
from dotenv import load_dotenv
from google import genai
from google.genai import types

# ------------------ Setup ------------------
load_dotenv()
client = genai.Client(api_key=st.secrets["GOOGLE_API_KEY"])

st.set_page_config(page_title="Gemini Thinking Chat", page_icon="🤖")
st.title("🤖 Gemini Thinking Chat")
st.caption("Streaming • Google Search • Dynamic Thinking")

# ------------------ Session State ------------------
if "messages" not in st.session_state:
    st.session_state.messages = []

# ------------------ Stream Helper ------------------
def stream_text(text, delay=0.01):
    for ch in text:
        yield ch
        time.sleep(delay)

# ------------------ Gemini Chat ------------------
def gemini_chat(prompt, history):
    with st.status("🧠 Thinking...", expanded=True) as status:
        thinking_box = st.empty()

        thoughts = ""
        answer = ""

        # Build conversation context
        conversation = ""
        for m in history:
            conversation += f"{m['role'].upper()}: {m['content']}\n"
        conversation += f"USER: {prompt}\n"

        for chunk in client.models.generate_content_stream(
            model="gemini-3-flash-preview",
            contents=conversation,
            config=types.GenerateContentConfig(
                thinking_config=types.ThinkingConfig(
                    include_thoughts=True,
                    thinking_budget=-1   # unlimited thinking
                ),
                temperature=0.3,
                max_output_tokens=2048,
            ),
        ):
            for part in chunk.candidates[0].content.parts:
                if not part.text:
                    continue

                if part.thought:
                    thoughts += part.text
                    thinking_box.write_stream(stream_text(thoughts))
                else:
                    answer += part.text

        status.update(label="✅ Thinking complete", state="complete", expanded=False)

    return thoughts, answer

# ------------------ UI ------------------
# Show previous messages
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# New input
user_prompt = st.chat_input("Ask anything...")

if user_prompt:
    st.session_state.messages.append({"role": "user", "content": user_prompt})
    st.chat_message("user").write(user_prompt)

    thoughts, answer = gemini_chat(user_prompt, st.session_state.messages[:-1])

    st.session_state.messages.append({"role": "assistant", "content": answer})

    with st.chat_message("assistant"):
        st.write_stream(stream_text(answer))
