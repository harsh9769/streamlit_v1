import streamlit as st

# -----------------------------
# LOGO (DEMO PATTERN – EXACT)
# -----------------------------
st.logo(
    "assets/icici_horizontal.png",      # wide header logo
    icon_image="assets/icici_icon.png",  # compact icon on collapse
    size="large",
    link="https://www.icicipruamc.com",
)

# -----------------------------
# PAGES
# -----------------------------
about_page = st.Page(
    "views/about_us.py",
    title="About Us",
    icon=":material/account_circle:",
    default=True,
)

# project_1_page = st.Page(
#     "views/sales_dashboard.py",
#     title="Sales Dashboard",
#     icon=":material/bar_chart:",
# )

project_2_page = st.Page(
    "views/thinking_chatbot.py",
    title="Chat Bot",
    icon=":material/smart_toy:",
)

project_3_page = st.Page(
    "views/stock_screener.py",
    title="Stock Screener",
    icon=":material/trending_up:",
)

# project_4_page = st.Page(
#     "views/reasoning_bot.py",
#     title="Reasoning Bot",
#     icon=":material/psychology:",
# )

# -----------------------------
# NAVIGATION
# -----------------------------

# "Info": [about_page],
pg = st.navigation(
    {
        
        "Projects": [project_3_page, project_2_page],
    }
)

st.sidebar.markdown("Made by ICICI Prudential AMC")

pg.run()
